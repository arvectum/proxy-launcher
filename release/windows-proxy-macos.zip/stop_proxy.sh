#!/bin/bash
# Остановка proxy-движка + снятие системного PAC (macOS)
cd "$(dirname "$0")"
python3 "$(dirname "$0")/proxy_core.py" --stop
echo "Proxy stopped, system PAC removed."