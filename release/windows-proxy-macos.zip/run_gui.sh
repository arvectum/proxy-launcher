#!/bin/bash
# Arvectum Proxy Launcher — запуск окна лаунчера (macOS)
cd "$(dirname "$0")"
PY=python3
if ! command -v python3 >/dev/null 2>&1; then
    echo "Python не установлен. Сначала запустите install.command"
    read -r -p "" x
    exit 1
fi
exec "$PY" "$(dirname "$0")/proxy_gui.py"